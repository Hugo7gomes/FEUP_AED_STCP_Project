var searchData=
[
  ['nearstops_0',['nearStops',['../class_menus.html#acb0e0eb5d2d1fcaf6307f3616450aad4',1,'Menus']]],
  ['node_1',['node',['../classnode.html',1,'node'],['../classnode.html#ab89bb38a671076258dc97d100aa79f60',1,'node::node()']]]
];
